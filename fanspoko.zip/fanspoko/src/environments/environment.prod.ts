export const environment = {
  production: true,
  API_URL:'http://mwdemoserver.com/516-FanSpoko/api',
  encryptSecretKey:'qFGxGJnygxTJ4no6hlVgAd8mUuxmzEes'
};
