import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
const API_URL = environment.API_URL;

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private bSubject = new BehaviorSubject(''); 
  public update_profile$ = this.bSubject.asObservable();
  constructor(private http: HttpClient) { }
  private _errorHandler(error: Response) {
    console.error('Error Occured: ' + error);
    return Observable.throw(error || 'Some Error on Server Occured');

  }
  user_profile_update(status){
    this.bSubject.next(status);
  }
  getCountries(){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/utilities/getCountries', { headers: headers })
      .catch(this._errorHandler);
  }

  getStates(CountryCode){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    let data ={
      CountryCode:CountryCode
    } 
    return this.http.post(API_URL + '/utilities/getStates',data, { headers: headers })
      .catch(this._errorHandler);
  }
  get_userInfo(sessionKey,UserGUID){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    let params  ={
      UserGUID:UserGUID,
      SessionKey:sessionKey,
      Params:'Gender,ProfilePic,Address,Postal,CountryCode,CityName,StateName,BirthDate,FirstName,LastName,PhoneNumber,Email'
    }
    return this.http.post(API_URL + '/users/getProfile',params, { headers: headers })
      .catch(this._errorHandler);
  }

  update_profile_image(data,sessionKey){
    const formData = new FormData();
    let file = data.target.files[0]; 
    formData.append("Section", "ProfilePic");
    formData.append("File", file,file.name);
    formData.append("SessionKey", sessionKey);
    let headers = new HttpHeaders();
        headers.append('mimeType', 'multipart/form-data');
        headers.append('Content-Type', 'application/json');
    
    return this.http.post(API_URL + '/upload/image',formData, { headers: headers })
      .catch(this._errorHandler);
  }
}
