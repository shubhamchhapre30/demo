import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs';
const API_URL = environment.API_URL;
@Injectable({
  providedIn: 'root'
})
export class ContestService {

  constructor(private http: HttpClient) { }
  private _errorHandler(error: Response) {
    console.error('Error Occured: ' + error);
    return Observable.throw(error || 'Some Error on Server Occured');

  }

  get_contests(SessionKey){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    let data = {
      SessionKey : SessionKey,
      Privacy:'No',
      Params:'IsPaid,ContestSize,StartWeekID,EndWeekID,TotalJoined,Status'
    }
    return this.http.post(API_URL + '/contest/getContests', data,{headers:headers}).catch(this._errorHandler);
  }

  get_contest(SessionKey,UserGUID){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    let data = {
      SessionKey : SessionKey,
      ContestGUID: UserGUID,
      Params:'IsPaid,ContestSize,StartWeekID,EndWeekID,ContestType,Elimination,ImmunityWeek,NoOfWinners,WinningAmount'
    }
    return this.http.post(API_URL + '/contest/getContest', data,{headers:headers}).catch(this._errorHandler);
  }
}
