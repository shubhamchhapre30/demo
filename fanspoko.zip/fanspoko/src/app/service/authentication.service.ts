import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs';
import * as CryptoJS from 'crypto-js';
const API_URL = environment.API_URL;
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }
  private _errorHandler(error: Response) {
    console.error('Error Occured: ' + error);
    return Observable.throw(error || 'Some Error on Server Occured');

  }

  loggedIn() {
    if (this.decryptData(localStorage.getItem('is_login')) == 'true') {
      return true;
    } else {
      return false;
    }
  }
  decryptData(data:any) {
    try {
      const bytes = CryptoJS.AES.decrypt(data, environment.encryptSecretKey);
      if (bytes.toString()) {
        return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      }
      return data;
    } catch (e) {
      
    }
  }

  userInfo() {
    var data = this.decryptData(localStorage.getItem('userinfo'));
    return data;
  }
  encryptData(data:any) {
    try {
      return CryptoJS.AES.encrypt(JSON.stringify(data), environment.encryptSecretKey).toString();
    } catch (e) {
      console.log(e);
    }
  }

  signin(info:any) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/signin', info, { headers: headers })
      .catch(this._errorHandler);
  }


  signout(session_info:any) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/signin/signout', session_info, { headers: headers })
      .catch(this._errorHandler);
  }

  signup(data:any){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/signup', data, { headers: headers })
      .catch(this._errorHandler);
  }

  forgetPassword(info:any){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/recovery', info, { headers: headers })
      .catch(this._errorHandler);
  }

  resetPassword(info:any){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/recovery/setPassword', info, { headers: headers })
      .catch(this._errorHandler);
  }

  update_user_profile(data:any){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/users/updateUserInfo', data, { headers: headers })
      .catch(this._errorHandler);
  }

  social_login(data:any){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(API_URL + '/signup', data, { headers: headers })
      .catch(this._errorHandler);
  }
}
