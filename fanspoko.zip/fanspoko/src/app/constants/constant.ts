export class Constant {
    static readonly DATE_FMT = 'yyyy-MM-dd';
    static readonly GOOGLE_CLIENT_ID_PROD = '597256090889-4081t9d5iav9nngtku5i062tgr0jf8r0.apps.googleusercontent.com';
    static readonly GOOGLE_CLIENT_ID_DEV = '597256090889-6tjmq7rrir4mluhcjqrrt516qs91tm0b.apps.googleusercontent.com';
    static readonly FACEBOOK_APP_ID_PROD = '831775380554426';
    static readonly FACEBOOK_APP_ID_DEV = '831775380554426'; 
}
