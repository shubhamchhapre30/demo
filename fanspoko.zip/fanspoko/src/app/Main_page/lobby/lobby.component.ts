import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../service/authentication.service';
import { ContestService } from '../../service/contest.service';
import { ToastrManager } from 'ng6-toastr-notifications';
declare const $: any;
@Component({
  selector: 'app-lobby',
  templateUrl: './lobby.component.html',
  styleUrls: ['./lobby.component.css']
})
export class LobbyComponent implements OnInit {
  contest_list: any = [];
  session_key: any = '';
  constructor(private contestService: ContestService, private service: AuthenticationService, private toast: ToastrManager) { }

  ngOnInit() {
    this.session_key = this.service.decryptData(localStorage.getItem('session_key'));
    this.contestService.get_contests(this.session_key).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        var contests = data.Data.Records;
        contests.forEach(element => {
          let joinPercent = parseInt(element.TotalJoined) * 100 / parseInt(element.ContestSize);
          element.joinPercent = joinPercent;
          this.contest_list.push(element);
        });

      } else {
        this.toast.errorToastr(data.Message);
      }
    }, error => {
      console.log(error);
    });

  }

  open_join_pool_modal() {
    $("#conformation").modal('show');
  }

  close_join_pool_modal() {
    $("#conformation").modal('hide');
  }

  identify(index, item) {
    return item.ContestGUID;
  }
}
