import { Component, OnInit } from '@angular/core';
import { AuthenticationService} from '../../service/authentication.service';
import {environment} from '../../../environments/environment';
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  constructor(private service:AuthenticationService) { 
    
  }

  ngOnInit() {
  }
  
}
