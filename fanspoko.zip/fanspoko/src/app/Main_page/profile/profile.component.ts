import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../service/authentication.service';
import { CommonService } from '../../service/common.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import {DateFormatPipe} from '../../pipes/date-format.pipe';
import {environment} from '../../../environments/environment';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  providers:[DateFormatPipe]
})
export class ProfileComponent implements OnInit {
  countries: any = [];
  update_profile: FormGroup;
  BirthDate: any = '';
  user_info: any = [];
  SessionKey: any = '';
  config:any= { // Change this to your upload POST address:  
    url: environment.API_URL+'/upload/image',
    method:'post' ,
    clickable:true,
    paramName: "File",
    previewTemplate:"<span></span>",
    autoReset:1000,
  };
  constructor(private dateFormat:DateFormatPipe,private formBuilder: FormBuilder, private service: AuthenticationService, private commonService: CommonService, private toast: ToastrManager) {
    this.user_info = this.service.userInfo();
    this.SessionKey = this.service.decryptData(localStorage.getItem('session_key'));
  }

  ngOnInit() {
    this.config.params = {
      Section:'ProfilePic',
      SessionKey:this.SessionKey
    }
    this.commonService.getCountries().subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.countries = data.Data['Records'];
      } else {
        this.toast.errorToastr(data.Message);
      }
    },
      error => {
        this.toast.errorToastr(error);
      })

    this.BirthDate = new FormControl({value:new Date(this.user_info.BirthDate),disabled: true});
    this.update_profile = this.formBuilder.group({
      FirstName: [this.user_info.FirstName, Validators.required],
      LastName: [this.user_info.LastName, Validators.required],
      Gender: [this.user_info.Gender],
      BirthDate: [this.user_info.BirthDate],
      PhoneNumber: [this.user_info.PhoneNumber],
      CountryCode: [this.user_info.CountryCode],
      CityName: [this.user_info.CityName],
      StateName: [this.user_info.StateName],
      Postal: [this.user_info.Postal],
      Address: [this.user_info.Address]
    })
  }

  update_local_user_info() {
    this.commonService.get_userInfo(this.SessionKey, this.user_info.UserGUID).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        if (data.ResponseCode == 200) {
          localStorage.setItem('userinfo', this.service.encryptData(data.Data));
          this.user_info = this.service.userInfo();
        }
      } else {
        this.toast.errorToastr(data.Message);
      }
    });
  }

  update_profile_info(info) {
    if (this.BirthDate.value != 'Invalid Date') {
      info.BirthDate = this.dateFormat.transform(this.BirthDate.value);
    }
    info.SessionKey = this.service.decryptData(localStorage.getItem('session_key'));
    this.service.update_user_profile(info).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.toast.successToastr(data.Message);
        this.update_local_user_info();
        this.commonService.user_profile_update({ 'profile_update': true });
      } else {
        this.toast.errorToastr(data.Message);
      }
    })
  }

  change_image(event){
    this.commonService.update_profile_image(event,this.SessionKey).subscribe((data:any)=>{
      if (data.ResponseCode == 200) {
        this.toast.successToastr("Profile image "+data.Message);
        this.update_local_user_info();
        this.commonService.user_profile_update({ 'profile_update': true });
      } else {
        this.toast.errorToastr(data.Message);
      }
    },error=>{
      this.toast.errorToastr(error);
    })
  }

}
