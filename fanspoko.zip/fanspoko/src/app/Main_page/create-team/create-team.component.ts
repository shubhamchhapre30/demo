import { Component, OnInit, OnDestroy } from '@angular/core';
import { SportService } from '../../service/sport.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import * as _ from "lodash";
import { ContestService } from '../../service/contest.service';
import { AuthenticationService } from '../../service/authentication.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.css']
})
export class CreateTeamComponent implements OnInit, OnDestroy {
  Player_List_ALL: any = [];
  All_Players_List: any = [];
  Player_List_QB: any = [];
  Player_List_WR: any = [];
  Player_List_RB: any = [];
  Player_List_TE: any = [];
  Player_List_DST: any = [];
  Player_List_K: any = [];
  Team_Size: number = 16;
  Team_Players: any = [];
  QB_Players: number = 0;
  WR_Players: number = 0;
  RB_Players: number = 0;
  TE_Players: number = 0;
  DST_Players: number = 0;
  K_Players: number = 0;
  searchText: any = '';
  Max_QB_Players: number = 4;
  Max_RB_Players: number = 8;
  Max_WR_Players: number = 8;
  Max_TE_Players: number = 3;
  Max_DST_Players: number = 3;
  Max_K_Players: number = 3;
  Min_QB_Players: number = 1;
  Min_RB_Players: number = 2;
  Min_WR_Players: number = 2;
  Min_TE_Players: number = 1;
  Min_DST_Players: number = 1;
  Min_K_Players: number = 1;
  Contest_Info: any = [];
  Session_Key: any = '';
  ContestGUID: any = '';
  queryParamater: any;
  constructor(private route: ActivatedRoute, private contestService: ContestService, private sportService: SportService, private toast: ToastrManager, private service: AuthenticationService) {
    this.Session_Key = this.service.decryptData(localStorage.getItem('session_key'));
    this.queryParamater = this.route.queryParams.subscribe(params => {
          this.ContestGUID = params.ContestGUID;
    });
  }

  ngOnInit() {
    this.contestService.get_contest(this.Session_Key, this.ContestGUID).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.Contest_Info = data.Data;
      } else {
        this.toast.successToastr(data.Message);
      }
    }, error => {
      this.toast.errorToastr(error);
    })


    this.sportService.getPlayers().subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.Player_List_ALL = data.Data.Records;
        this.Player_List_ALL.forEach(element => {
          element.selected = false;
          this.All_Players_List.push(element)
        });
        this.categories_player();
      }
    }, error => {
      this.toast.errorToastr(error.Message);
    });
  }

  ngOnDestroy() {
    this.queryParamater.unsubscribe();
  }

  identify(index, item) {
    return item.PlayerRole;
  }

  categories_player() {
    this.All_Players_List.forEach((element, index) => {
      if (element.PlayerRole == 'QuarterBack') {
        this.Player_List_QB.push(element);
      } else if (element.PlayerRole == 'WideReceiver') {
        this.Player_List_WR.push(element);
      } else if (element.PlayerRole == 'RunningBack') {
        this.Player_List_RB.push(element);
      } else if (element.PlayerRole == 'TightEnd') {
        this.Player_List_TE.push(element);
      } else if (element.PlayerRole == 'DefenseTackle') {
        this.Player_List_DST.push(element);
      } else if (element.PlayerRole == 'Placekicker') {
        this.Player_List_K.push(element);
      }
    });
  }

  select_team_player(info:any) {
    if (this.Team_Players.length < this.Team_Size) {
      let total_role_player = this.role_wise_player_count(info.PlayerRole);
      /**
       * Condition for checking max value by roles.
       */
      if (info.PlayerRole == 'QuarterBack' && total_role_player < this.Max_QB_Players) {
        this.QB_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else if (info.PlayerRole == 'WideReceiver' && total_role_player < this.Max_WR_Players) {
        this.WR_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else if (info.PlayerRole == 'RunningBack' && total_role_player < this.Max_RB_Players) {
        this.RB_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else if (info.PlayerRole == 'TightEnd' && total_role_player < this.Max_TE_Players) {
        this.TE_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else if (info.PlayerRole == 'DefenseTackle' && total_role_player < this.Max_DST_Players) {
        this.DST_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else if (info.PlayerRole == 'Placekicker' && total_role_player < this.Max_K_Players) {
        this.K_Players = total_role_player + 1;
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == info.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(info);
      } else {
        this.toast.errorToastr('Already maximum ' + info.PlayerRole + ' players are selected.');
      }
    } else {
      this.toast.errorToastr('You cann\'t add more than '+this.Team_Size+' players.')
    }
  }


  remove_team_player(PlayerGUID) {
    this.Team_Players.forEach((element, index) => {
      if (element.PlayerGUID == PlayerGUID) {
        this.Team_Players.splice(index, 1);
      }
      if (element.PlayerRole == 'QuarterBack') {
        this.QB_Players = this.role_wise_player_count('QuarterBack');
      } else if (element.PlayerRole == 'WideReceiver') {
        this.WR_Players = this.role_wise_player_count('WideReceiver');
      } else if (element.PlayerRole == 'RunningBack') {
        this.RB_Players = this.role_wise_player_count('RunningBack');
      } else if (element.PlayerRole == 'TightEnd') {
        this.TE_Players = this.role_wise_player_count('TightEnd');
      } else if (element.PlayerRole == 'DefenseTackle') {
        this.DST_Players = this.role_wise_player_count('DefenseTackle');
      } else if (element.PlayerRole == 'Placekicker') {
        this.K_Players = this.role_wise_player_count('Placekicker');
      }
    });
    this.All_Players_List.forEach(element => {
      if (element.PlayerGUID == PlayerGUID) {
        element.selected = false;
      }
    });
  }

  role_wise_player_count(type) {
    /**
      * Count role wise player
      */
    let total_role_player: number = 0;
    this.Team_Players.forEach(element => {
      if (element.PlayerRole == type) {
        total_role_player++;
      }
    });
    return total_role_player
  }

  role_wise_player_list(type) {
    let roleWisePlayerList: any = [];
    switch (type) {
      case 'QuarterBack': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
      case 'WideReceiver': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
      case 'RunningBack': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
      case 'TightEnd': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
      case 'DefenseTackle': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
      case 'Placekicker': {
        this.Team_Players.forEach(element => {
          if (element.PlayerRole == type) {
            roleWisePlayerList.push(element);
          }
        });
        break;
      }
    }
    return roleWisePlayerList;
  }

  submit_team() {
    if (this.QB_Players < this.Min_QB_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_QB_Players + ' QuarterBack player required.');
      return false;
    }
    if (this.WR_Players < this.Min_WR_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_WR_Players + ' WideReceiver player required.');
      return false;
    }
    if (this.RB_Players < this.Min_RB_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_RB_Players + ' RunningBack player required.');
      return false;
    }
    if (this.TE_Players < this.Min_TE_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_TE_Players + ' TightEnd player required.');
      return false;
    }
    if (this.DST_Players < this.Min_DST_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_DST_Players + ' DefenseTackle player required.');
      return false;
    }
    if (this.K_Players < this.Min_K_Players) {
      this.toast.errorToastr('Atleast ' + this.Min_K_Players + ' Placekicker player required.');
      return false;
    }
    if (this.Team_Players.length < this.Team_Size) {
      this.toast.errorToastr('Please select total ' + this.Team_Size + ' players.');
      return false;
    }
    this.toast.successToastr('Team created successfully.');

  }

  clear_team() {
    this.All_Players_List.forEach(element => {
      this.Team_Players.forEach(element1 => {
        if (element.PlayerGUID == element1.PlayerGUID) {
          element.selected = false;
        }
      });
    });
    this.Team_Players.length = 0;
    this.QB_Players = 0;
    this.RB_Players = 0;
    this.TE_Players = 0;
    this.DST_Players = 0;
    this.WR_Players = 0;
    this.K_Players = 0;
  }

  autoFill_team_players() {
    this.clear_team();
    let players_roles: any = ['QuarterBack', 'WideReceiver', 'RunningBack', 'TightEnd', 'DefenseTackle', 'Placekicker'];
    for (let index = 0; index < this.Team_Size; index++) {
      /**
       * Condition for checking max value by roles.
       */
      if (players_roles.includes('QuarterBack') && this.role_wise_player_count('QuarterBack') < 3) {
        this.QB_Players = this.role_wise_player_count('QuarterBack') + 1;
        let players: any = this.Player_List_QB[_.random(0, this.Player_List_QB.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      } else if (players_roles.includes('WideReceiver') && this.role_wise_player_count('WideReceiver') < 3) {
        this.WR_Players = this.role_wise_player_count('WideReceiver') + 1;
        let players: any = this.Player_List_WR[_.random(0, this.Player_List_WR.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      } else if (players_roles.includes('RunningBack') && this.role_wise_player_count('RunningBack') < 3) {
        this.RB_Players = this.role_wise_player_count('RunningBack') + 1;
        let players: any = this.Player_List_RB[_.random(0, this.Player_List_RB.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      } else if (players_roles.includes('TightEnd') && this.role_wise_player_count('TightEnd') < 2) {
        this.TE_Players = this.role_wise_player_count('TightEnd') + 1;
        let players: any = this.Player_List_TE[_.random(0, this.Player_List_TE.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      } else if (players_roles.includes('DefenseTackle') && this.role_wise_player_count('DefenseTackle') < 2) {
        this.DST_Players = this.role_wise_player_count('DefenseTackle') + 1;
        let players: any = this.Player_List_DST[_.random(0, this.Player_List_DST.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      } else if (players_roles.includes('Placekicker') && this.role_wise_player_count('Placekicker') < 3) {
        this.K_Players = this.role_wise_player_count('Placekicker') + 1;
        let players: any = this.Player_List_K[_.random(0, this.Player_List_K.length - 1)];
        this.All_Players_List.forEach(element => {
          if (element.PlayerGUID == players.PlayerGUID) {
            element.selected = true;
          }
        });
        this.Team_Players.push(players);
      }
    }
  }

}
