import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule,routingComponent } from './app-routing.module';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ng6-toastr-notifications';
import { CookieService } from 'ngx-cookie-service';
import { BsModalModule } from 'ng2-bs3-modal';
import { MAT_DATE_LOCALE, DateAdapter, MatDatepickerModule, MatNativeDateModule, MatFormFieldModule, MatInputModule, MAT_DATE_FORMATS } from '@angular/material';
import { FilterPipe } from './pipes/search.filter.pipe';
import { SocialLoginModule, AuthServiceConfig } from "angularx-social-login";
import { GoogleLoginProvider, FacebookLoginProvider } from "angularx-social-login";
import { DateFormatPipe } from './pipes/date-format.pipe';
import { Constant } from './constants/constant';
import { environment } from '../environments/environment';
import { MomentDateModule, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'DD/MM/YYYY',
    monthYearA11yLabel: 'MMm YYYY',
  },
};
var GOOGLE_CLIENT_ID = Constant.GOOGLE_CLIENT_ID_DEV;
var FACEBOOK_APP_ID = Constant.FACEBOOK_APP_ID_DEV;
if (environment.production) {
  GOOGLE_CLIENT_ID = Constant.GOOGLE_CLIENT_ID_PROD;
  FACEBOOK_APP_ID = Constant.FACEBOOK_APP_ID_PROD;
}
let config = new AuthServiceConfig([
  {
    id: GoogleLoginProvider.PROVIDER_ID,
    provider: new GoogleLoginProvider(GOOGLE_CLIENT_ID)
  },
  {
    id: FacebookLoginProvider.PROVIDER_ID,
    provider: new FacebookLoginProvider(FACEBOOK_APP_ID)
  }
]);

export function provideConfig() {
  return config;
}
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FilterPipe,
    DateFormatPipe,
    routingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    CommonModule,
    BsModalModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    SocialLoginModule,
    MomentDateModule,
    DropzoneModule
  ],
  providers: [CookieService, MatNativeDateModule, {
    provide: AuthServiceConfig,
    useFactory: provideConfig
  },
    { provide: MAT_DATE_LOCALE, useValue: 'utc' }, //you can change useValue
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
