import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate, Router } from '@angular/router';
import { IndexComponent } from './Main_page/index/index.component';
import { LoginComponent } from './home/login/login.component';
import { ProfileComponent } from './Main_page/profile/profile.component';
import { SignupComponent } from './home/signup/signup.component';
import { ResetPasswordComponent } from './home/reset-password/reset-password.component';
import { AuthGuard } from './guards/auth.guard';
import { CreateTeamComponent } from './Main_page/create-team/create-team.component';
import { LobbyComponent } from './Main_page/lobby/lobby.component';
import { MainPageComponent } from './Main_page/main-page.component';
import { PageNotFoundComponent } from './home/page-not-found/page-not-found.component';
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'resetpassword', component: ResetPasswordComponent },
  {
    path: 'index', component: MainPageComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: IndexComponent },
      { path: 'lobby', component: LobbyComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'create_team', component: CreateTeamComponent }
    ]
  },
  { path: '**', component: PageNotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent = [IndexComponent,LoginComponent,SignupComponent,ResetPasswordComponent,MainPageComponent,LobbyComponent,ProfileComponent,CreateTeamComponent,PageNotFoundComponent
]

