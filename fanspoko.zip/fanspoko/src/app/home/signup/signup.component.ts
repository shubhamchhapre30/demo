import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../service/authentication.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {PasswordMatchValidation} from '../../providers/custom.passwordValidation';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signup:FormGroup;
  DisableSignup:boolean = false;
  constructor(private router:Router,private formbuilder:FormBuilder,private service:AuthenticationService,private toast:ToastrManager) { }

  ngOnInit() {
    this.signup = this.formbuilder.group({
      email:['',Validators.compose([Validators.required,Validators.email])],
      password:['',Validators.compose([Validators.required,Validators.minLength(6)])],
      confirm_password:['',Validators.compose([Validators.required])]
      },{
        validator:PasswordMatchValidation.MatchPassword
      })
  }

  sign_up(info){
    let signup = {
      Email: info.email,
      Password: info.password,
      Source: 'Direct',
      DeviceType: 'Native',
      UserTypeID: 2
    }
    this.service.signup(signup).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.toast.successToastr('Successfully registered, Please check Your mail.');
        this.router.navigateByUrl('/login');
      } else {
        this.toast.errorToastr(data.Message);
      }
    }, error => {
      this.toast.errorToastr(error.msg);
      console.log(error);
    })
  }

}
