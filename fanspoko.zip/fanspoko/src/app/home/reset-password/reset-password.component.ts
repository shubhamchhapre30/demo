import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../service/authentication.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {PasswordMatchValidation} from '../../providers/custom.passwordValidation';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  resetPass:FormGroup;
  constructor(private toast:ToastrManager, private service :AuthenticationService,private router:Router, private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.resetPass = this.formBuilder.group({
      otp:['',Validators.required],
      password:['',Validators.compose([Validators.required, Validators.minLength(6)])],
      confirm_password:['',Validators.compose([Validators.required])]
    },{ validator:PasswordMatchValidation.MatchPassword})
  }

  reset_password(data){
    var detail = {
      OTP:data.otp,
      Password:data.password
    }
    this.service.resetPassword(detail).subscribe((info:any)=>{
      if(info.ResponseCode == 200){
        this.router.navigate(['/login']);
        this.toast.successToastr(info.Message);
      }else{
        this.toast.errorToastr(info.Message);
      }
    },error=>{
      this.toast.errorToastr(error);
    })
  }
}
