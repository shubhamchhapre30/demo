import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthenticationService } from '../../service/authentication.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { BsModalComponent } from 'ng2-bs3-modal';
import { CommonService } from '../../service/common.service';
import { AuthService } from "angularx-social-login";
import { FacebookLoginProvider, GoogleLoginProvider } from "angularx-social-login";
declare const $: any;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  signin: FormGroup;
  forgetPassword: FormGroup;
  @ViewChild('forgot_pass')
  forgot_pass: BsModalComponent;
  constructor(private authService: AuthService, private commonService: CommonService, private cookieService: CookieService, private router: Router, private service: AuthenticationService, private toast: ToastrManager, private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    var info = this.cookieService.get('login_credentials');
    let email = '';
    let password = '';
    let remember_password = false;
    if (info != '') {
      let cookie_info = this.service.decryptData(info);
      email = cookie_info.email;
      password = cookie_info.password;
      remember_password = cookie_info.remember_password;
    }
    this.signin = this.formBuilder.group({
      email: [email, Validators.compose([Validators.required, Validators.email])],
      password: [password, Validators.required],
      remember_password: [remember_password]
    })
    if (this.service.loggedIn()) {
      this.router.navigate(['/index']);
    }

    this.forgetPassword = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required, Validators.email])]
    })
  }

  onLoginSubmit(info) {
    let signin = {
      Keyword: info.email,
      Password: info.password,
      Source: 'Direct',
      DeviceType: 'Native'
    }
    this.service.signin(signin).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        if (info.remember_password) {
          const today = new Date();
          const tomorrow = new Date(today.setDate(today.getDate() + 1));
          this.cookieService.set('login_credentials', this.service.encryptData(info), tomorrow);
        } else {
          this.cookieService.delete('login_credentials');
        }
        localStorage.setItem('session_key', this.service.encryptData(data.Data.SessionKey));
        localStorage.setItem('is_login', this.service.encryptData('true'));
        this.commonService.get_userInfo(data.Data.SessionKey, data.Data.UserGUID).subscribe((details: any) => {
          if (details.ResponseCode == 200) {
            localStorage.setItem('userinfo', this.service.encryptData(details.Data));
          }
        })
        this.router.navigateByUrl('/index');
        // this.toast.successToastr('User successfully loggedin.');
      } else {
        this.toast.errorToastr(data.Message);
      }
    }, error => {
      this.toast.errorToastr(error.msg);
      console.log(error);
    })
  }

  forget_password(info) {
    let details = {
      Keyword: info.email
    }
    this.service.forgetPassword(details).subscribe((data: any) => {
      if (data.ResponseCode == 200) {
        this.toast.successToastr(data.Message);
        this.forgetPassword.reset();
        $('#forget_pass').modal('hide');
        this.router.navigate(['/resetpassword']);
      } else {
        this.toast.errorToastr(data.Message);
      }
    }, error => {
      this.toast.errorToastr(error);
    })
  }

  forget_modal() {
    $("#forget_pass").modal('show');
  }

  close_forget_modal() {
    this.forgetPassword.reset();
    $('#forget_pass').modal('hide');
  }

  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }
    this.authService.signIn(socialPlatformProvider).then(
      (userData) => {
        console.log(socialPlatform + " sign in data : ", userData);
        let social_signin = {
          Email: userData.email,
          FirstName: userData.firstName,
          LastName: userData.lastName,
          Source: userData.provider == 'GOOGLE' ? 'Google' : 'Facebook',
          DeviceType: 'Native',
          SourceGUID: userData.authToken,
          UserTypeID: 2
        }
        this.service.social_login(social_signin).subscribe((data: any) => {
          if (data.ResponseCode == 200) {
            localStorage.setItem('social_login_data', this.service.encryptData(userData));
            localStorage.setItem('session_key', this.service.encryptData(data.Data.SessionKey));
            localStorage.setItem('is_login', this.service.encryptData('true'));
            this.commonService.get_userInfo(data.Data.SessionKey, data.Data.UserGUID).subscribe((details: any) => {
              if (details.ResponseCode == 200) {
                localStorage.setItem('userinfo', this.service.encryptData(details.Data));
              }
            })
            this.router.navigateByUrl('/index');
            // this.toast.successToastr('User successfully loggedin.');
          } else {
            this.toast.errorToastr(data.Message);
          }
        }, error => {
          this.toast.errorToastr(error.msg);
          console.log(error);
        });

      }, error => {
        this.toast.errorToastr(error);
      }
    );
  }

}
