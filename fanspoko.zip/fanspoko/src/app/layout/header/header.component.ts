import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../service/authentication.service';
import {Router} from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import {CommonService} from '../../service/common.service';
import { AuthService } from "angularx-social-login";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loginStatus:Boolean = false;
  user_info:any = [];
  constructor(private authService: AuthService,private commonService:CommonService,private router:Router,private service:AuthenticationService,private toast:ToastrManager) { 
    if(this.service.loggedIn()){
      this.loginStatus = true;
    }
  }

  ngOnInit() {
    setTimeout(()=>{ 
      this.user_info = this.service.userInfo();
    }, 100);
    this.commonService.update_profile$.subscribe((data:any)=>{
      if(data.profile_update){
        setTimeout(()=>{ 
          this.user_info = this.service.userInfo();
        }, 100);
      }
    })
  }

  logout(){
    let session_data = {
      'SessionKey':this.service.decryptData(localStorage.getItem('session_key'))
    }
    this.service.signout(session_data).subscribe( (data:any)=>{
      if(data.ResponseCode == 200){
        localStorage.clear();
        if(localStorage.getItem('social_login_data')){
          this.social_signOut();
        }
        this.router.navigate(['login']);
        this.toast.successToastr('Logout successfully');
      }else{
        this.toast.errorToastr(data.Message);
      }
    },error=>{
      this.toast.errorToastr(error);
    })
    
  }
  social_signOut(): void {
    this.authService.signOut();
  }
}
