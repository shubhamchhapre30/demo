//loader start
    var animsition_pages;
    function myFunction() {
      animsition_pages = setTimeout(showPage, 00);
    }
    function showPage() {
      $("#loader").css("display", "none");
      $("#loderBG").removeClass("loderBG");
      $("body").css("overflow", "auto");
      $(".animsition").addClass("active");
    }
//loader end
$(document).ready(function() {

  // slider
  $(".bannerSlider").slick({
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    arrows: true,
  });

  });